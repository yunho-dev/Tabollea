package kr.co.tayo.dto;

public class MypageDTO {
	private String mem_id;
	private String mem_pw;
	private String mem_pnum;
	private String mem_email;
	private String mem_add;
	private String mem_detailAdd;
	private String mem_name;
	private String mem_age;
	private String mem_mar;
	private String mem_child;
	private String mem_mbti;
	private String mem_fam;
	private String mem_bcnt;
	private String mem_power;
	
	public String getMem_power() {
		return mem_power;
	}
	public void setMem_power(String mem_power) {
		this.mem_power = mem_power;
	}
	public String getMem_bcnt() {
		return mem_bcnt;
	}
	public void setMem_bcnt(String mem_bcnt) {
		this.mem_bcnt = mem_bcnt;
	}
	public String getMem_mar() {
		return mem_mar;
	}
	public void setMem_mar(String mem_mar) {
		this.mem_mar = mem_mar;
	}
	public String getMem_child() {
		return mem_child;
	}
	public void setMem_child(String mem_child) {
		this.mem_child = mem_child;
	}
	public String getMem_mbti() {
		return mem_mbti;
	}
	public void setMem_mbti(String mem_mbti) {
		this.mem_mbti = mem_mbti;
	}
	public String getMem_fam() {
		return mem_fam;
	}
	public void setMem_fam(String mem_fam) {
		this.mem_fam = mem_fam;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getMem_pw() {
		return mem_pw;
	}
	public void setMem_pw(String mem_pw) {
		this.mem_pw = mem_pw;
	}
	public String getMem_pnum() {
		return mem_pnum;
	}
	public void setMem_pnum(String mem_pnum) {
		this.mem_pnum = mem_pnum;
	}
	public String getMem_email() {
		return mem_email;
	}
	public void setMem_email(String mem_email) {
		this.mem_email = mem_email;
	}
	public String getMem_add() {
		return mem_add;
	}
	public void setMem_add(String mem_add) {
		this.mem_add = mem_add;
	}
	public String getMem_detailAdd() {
		return mem_detailAdd;
	}
	public void setMem_detailAdd(String mem_detailAdd) {
		this.mem_detailAdd = mem_detailAdd;
	}
	public String getMem_name() {
		return mem_name;
	}
	public void setMem_name(String mem_name) {
		this.mem_name = mem_name;
	}
	public String getMem_age() {
		return mem_age;
	}
	public void setMem_age(String mem_age) {
		this.mem_age = mem_age;
	}

}
