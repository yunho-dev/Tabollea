package kr.co.tayo.dto;

public class mainListDTO {
	private String ca_name;
	private String ca_age;
	private String ca_brand;
	private String ca_model;
	private String ca_price;
	private String ca_fuel;
	private int ca_num;
	private String ca_link;
	private int ca_cnt;
	private int ha_num;
	private String ha_name;
	private String ha_value;
	public String getCa_name() {
		return ca_name;
	}
	public void setCa_name(String ca_name) {
		this.ca_name = ca_name;
	}
	public String getCa_age() {
		return ca_age;
	}
	public void setCa_age(String ca_age) {
		this.ca_age = ca_age;
	}
	public String getCa_brand() {
		return ca_brand;
	}
	public void setCa_brand(String ca_brand) {
		this.ca_brand = ca_brand;
	}
	public String getCa_model() {
		return ca_model;
	}
	public void setCa_model(String ca_model) {
		this.ca_model = ca_model;
	}
	public String getCa_price() {
		return ca_price;
	}
	public void setCa_price(String ca_price) {
		this.ca_price = ca_price;
	}
	public String getCa_fuel() {
		return ca_fuel;
	}
	public void setCa_fuel(String ca_fuel) {
		this.ca_fuel = ca_fuel;
	}
	public int getCa_num() {
		return ca_num;
	}
	public void setCa_num(int ca_num) {
		this.ca_num = ca_num;
	}
	public String getCa_link() {
		return ca_link;
	}
	public void setCa_link(String ca_link) {
		this.ca_link = ca_link;
	}
	public int getCa_cnt() {
		return ca_cnt;
	}
	public void setCa_cnt(int ca_cnt) {
		this.ca_cnt = ca_cnt;
	}
	public int getHa_num() {
		return ha_num;
	}
	public void setHa_num(int ha_num) {
		this.ha_num = ha_num;
	}
	public String getHa_name() {
		return ha_name;
	}
	public void setHa_name(String ha_name) {
		this.ha_name = ha_name;
	}
	public String getHa_value() {
		return ha_value;
	}
	public void setHa_value(String ha_value) {
		this.ha_value = ha_value;
	}
	
	
}
