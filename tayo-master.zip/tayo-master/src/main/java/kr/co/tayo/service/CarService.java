package kr.co.tayo.service;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.tayo.dao.AdminCarDAO;
import kr.co.tayo.dto.CarDTO;
import kr.co.tayo.dto.FileDTO;
/*
 * @Service public class CarService { Logger logger =
 * LoggerFactory.getLogger(this.getClass());
 * 
 * @Autowired AdminCarDAO dao;
 * 
 * // 리스트 호출 public ArrayList<CarDTO> list() { logger.info("list service..");
 * 
 * return dao.list(); }
 * 
 * // 사진 호출 public ArrayList<FileDTO> imgList(String ca_num) {
 * logger.info("imgList service.."); return dao.imgList(ca_num); }
 * 
 * }
 */