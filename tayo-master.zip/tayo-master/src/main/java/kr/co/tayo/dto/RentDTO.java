package kr.co.tayo.dto;

public class RentDTO {
	private int ren_num;
	private String ren_name;
	private String ren_location;
	private String ren_sm;
	private String ren_mid;
	private String ren_big;
	private String ren_suv;
	private String ren_smprice;
	private String ren_midprice;
	private String ren_bigprice;
	private String ren_suvprice;
	private int ca_num;
	public int getRen_num() {
		return ren_num;
	}
	public void setRen_num(int ren_num) {
		this.ren_num = ren_num;
	}
	public String getRen_name() {
		return ren_name;
	}
	public void setRen_name(String ren_name) {
		this.ren_name = ren_name;
	}
	public String getRen_location() {
		return ren_location;
	}
	public void setRen_location(String ren_location) {
		this.ren_location = ren_location;
	}
	public String getRen_sm() {
		return ren_sm;
	}
	public void setRen_sm(String ren_sm) {
		this.ren_sm = ren_sm;
	}
	public String getRen_mid() {
		return ren_mid;
	}
	public void setRen_mid(String ren_mid) {
		this.ren_mid = ren_mid;
	}
	public String getRen_big() {
		return ren_big;
	}
	public void setRen_big(String ren_big) {
		this.ren_big = ren_big;
	}
	public String getRen_suv() {
		return ren_suv;
	}
	public void setRen_suv(String ren_suv) {
		this.ren_suv = ren_suv;
	}
	public String getRen_smprice() {
		return ren_smprice;
	}
	public void setRen_smprice(String ren_smprice) {
		this.ren_smprice = ren_smprice;
	}
	public String getRen_midprice() {
		return ren_midprice;
	}
	public void setRen_midprice(String ren_midprice) {
		this.ren_midprice = ren_midprice;
	}
	public String getRen_bigprice() {
		return ren_bigprice;
	}
	public void setRen_bigprice(String ren_bigprice) {
		this.ren_bigprice = ren_bigprice;
	}
	public String getRen_suvprice() {
		return ren_suvprice;
	}
	public void setRen_suvprice(String ren_suvprice) {
		this.ren_suvprice = ren_suvprice;
	}
	public int getCa_num() {
		return ca_num;
	}
	public void setCa_num(int ca_num) {
		this.ca_num = ca_num;
	}
	
	

}
