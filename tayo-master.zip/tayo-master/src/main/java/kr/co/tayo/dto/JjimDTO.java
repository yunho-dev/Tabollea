package kr.co.tayo.dto;

public class JjimDTO {
	private int jj_num;
	private String mem_id;
	private int fi_num;
	private int ca_num;
	
	public int getJj_num() {
		return jj_num;
	}
	public void setJj_num(int jj_num) {
		this.jj_num = jj_num;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public int getFi_num() {
		return fi_num;
	}
	public void setFi_num(int fi_num) {
		this.fi_num = fi_num;
	}
	public int getCa_num() {
		return ca_num;
	}
	public void setCa_num(int ca_num) {
		this.ca_num = ca_num;
	}
	
	
}
